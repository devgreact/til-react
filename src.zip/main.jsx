import { createRoot } from "react-dom/client";

import Sample5 from "./event-sample/Sample5";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <>
    <Sample5 />
  </>,
);
