export const BannerStyleObj = {
  display: "flex",
  backgroundColor: "blue",
  width: "calc(100% / 3)",
  height: "200px",
  alignItems: "center",
  justifyContent: "center",
};
