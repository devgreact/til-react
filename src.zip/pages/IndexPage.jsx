import Footer from "../components/footer/Footer";
import Header from "../components/header/Header";
import "../styles/pages/index-page.css";
function IndexPage() {
  return (
    <>
      <Header></Header>
      <main className="main">
        <div className="slide">슬라이드</div>
        <div className="content">
          <div className="notice">공지사항</div>
          <div className="banner">배너</div>
          <div className="link">바로가기</div>
        </div>
      </main>
      <Footer></Footer>
    </>
  );
}

export default IndexPage;
