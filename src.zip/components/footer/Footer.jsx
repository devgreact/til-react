const Footer = () => {
  return (
    <footer className="footer">
      <a href="#" className="footer-logo">
        로고
      </a>
      <p className="copyright">Copyright</p>
      <div className="sns">SNS</div>
    </footer>
  );
};

export default Footer;
